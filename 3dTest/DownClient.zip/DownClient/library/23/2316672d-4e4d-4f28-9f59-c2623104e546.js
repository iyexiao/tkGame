"use strict";

System.register("project:///assets/Scripts/PlayerCtrl.ts", [], function (_export, _context) {
  "use strict";

  var _dec, _dec2, _class, _class2, _descriptor, _temp, _cc, _decorator, Component, math, systemEvent, SystemEvent, AnimationComponent, ccclass, property, PlayerCtrl;

  _export({
    _dec: void 0,
    _dec2: void 0,
    _class: void 0,
    _class2: void 0,
    _descriptor: void 0,
    _temp: void 0
  });

  return {
    setters: [],
    execute: function () {
      cc._RF.push(window.module || {}, "23166ctTk1PKJ9ZwmIxBOVG", "PlayerCtrl"); // begin PlayerCtrl


      _cc = cc;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      math = _cc.math;
      systemEvent = _cc.systemEvent;
      SystemEvent = _cc.SystemEvent;
      AnimationComponent = _cc.AnimationComponent;
      ccclass = _decorator.ccclass;
      property = _decorator.property;

      _export("PlayerCtrl", PlayerCtrl = (_dec = ccclass("PlayerCtrl"), _dec2 = property({
        type: AnimationComponent
      }), _dec(_class = (_class2 = (_temp =
      /*#__PURE__*/
      function (_Component) {
        babelHelpers.inherits(PlayerCtrl, _Component);

        function PlayerCtrl() {
          var _babelHelpers$getProt;

          var _this;

          babelHelpers.classCallCheck(this, PlayerCtrl);

          for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
          }

          _this = babelHelpers.possibleConstructorReturn(this, (_babelHelpers$getProt = babelHelpers.getPrototypeOf(PlayerCtrl)).call.apply(_babelHelpers$getProt, [this].concat(args)));
          _this.startJump = false;
          _this.jumpStep = 0;
          _this.currJumpTime = 0;
          _this.jumpTime = 0.1;
          _this.currJumpSpeed = 0;
          _this.currPos = cc.v3(0, 0, 0);
          _this.deltaPos = cc.v3(0, 0, 0);
          _this.targetPos = cc.v3(0, 0, 0);
          _this.isMoving = false;
          _this.currMoveIndex = 0;
          babelHelpers.initializerDefineProperty(_this, "BodyAnim", _descriptor, babelHelpers.assertThisInitialized(_this));
          return _this;
        }

        babelHelpers.createClass(PlayerCtrl, [{
          key: "start",
          value: function start() {}
        }, {
          key: "reset",
          value: function reset() {
            this.currMoveIndex = 0;
          }
        }, {
          key: "setInputActive",
          value: function setInputActive(active) {
            if (active) {
              systemEvent.on(SystemEvent.EventType.MOUSE_UP, this.onMouseUp, this);
            } else {
              systemEvent.off(SystemEvent.EventType.MOUSE_UP, this.onMouseUp, this);
            }
          }
        }, {
          key: "onMouseUp",
          value: function onMouseUp(event) {
            if (event.getButton() === 0) {
              this.jumpByStep(1);
            } else if (event.getButton() === 2) {
              this.jumpByStep(2);
            }
          }
        }, {
          key: "jumpByStep",
          value: function jumpByStep(step) {
            if (this.isMoving) {
              return;
            }

            this.startJump = true;
            this.jumpStep = step;
            this.currJumpTime = 0;
            this.currJumpSpeed = this.jumpStep / this.jumpTime;
            this.node.getPosition(this.currPos);
            math.Vec3.add(this.targetPos, this.currPos, cc.v3(this.jumpStep, 0, 0));
            this.isMoving = true;

            if (this.BodyAnim) {
              if (step === 1) {
                this.BodyAnim.play('OneStep');
              } else if (step === 2) {
                this.BodyAnim.play('TwoStep');
              }
            }

            this.currMoveIndex += step;
          }
        }, {
          key: "onOnceJumpEnd",
          value: function onOnceJumpEnd() {
            this.isMoving = false;
            this.node.emit('JumpEnd', this.currMoveIndex);
          }
        }, {
          key: "update",
          value: function update(deltaTime) {
            if (this.startJump) {
              this.currJumpTime += deltaTime;

              if (this.currJumpTime > this.jumpTime) {
                // end
                this.node.setPosition(this.targetPos);
                this.startJump = false;
                this.onOnceJumpEnd();
              } else {
                // tween
                this.node.getPosition(this.currPos);
                this.deltaPos.x = this.currJumpSpeed * deltaTime;
                math.Vec3.add(this.currPos, this.currPos, this.deltaPos);
                this.node.setPosition(this.currPos);
              }
            }
          }
        }]);
        return PlayerCtrl;
      }(Component), _temp), (_descriptor = babelHelpers.applyDecoratedDescriptor(_class2.prototype, "BodyAnim", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      })), _class2)) || _class));

      cc._RF.pop(); // end PlayerCtrl

    }
  };
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInByb2plY3Q6Ly8vYXNzZXRzL1NjcmlwdHMvUGxheWVyQ3RybC50cyJdLCJuYW1lcyI6WyJjY2NsYXNzIiwiX2RlY29yYXRvciIsInByb3BlcnR5IiwiUGxheWVyQ3RybCIsInR5cGUiLCJBbmltYXRpb25Db21wb25lbnQiLCJzdGFydEp1bXAiLCJqdW1wU3RlcCIsImN1cnJKdW1wVGltZSIsImp1bXBUaW1lIiwiY3Vyckp1bXBTcGVlZCIsImN1cnJQb3MiLCJjYyIsInYzIiwiZGVsdGFQb3MiLCJ0YXJnZXRQb3MiLCJpc01vdmluZyIsImN1cnJNb3ZlSW5kZXgiLCJhY3RpdmUiLCJzeXN0ZW1FdmVudCIsIm9uIiwiU3lzdGVtRXZlbnQiLCJFdmVudFR5cGUiLCJNT1VTRV9VUCIsIm9uTW91c2VVcCIsIm9mZiIsImV2ZW50IiwiZ2V0QnV0dG9uIiwianVtcEJ5U3RlcCIsInN0ZXAiLCJub2RlIiwiZ2V0UG9zaXRpb24iLCJtYXRoIiwiVmVjMyIsImFkZCIsIkJvZHlBbmltIiwicGxheSIsImVtaXQiLCJkZWx0YVRpbWUiLCJzZXRQb3NpdGlvbiIsIm9uT25jZUp1bXBFbmQiLCJ4IiwiQ29tcG9uZW50Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O2lGQUV5RTs7Ozs7Ozs7OztBQURqRUEsTUFBQUEsTyxHQUFzQkMsVSxDQUF0QkQsTztBQUFTRSxNQUFBQSxRLEdBQWFELFUsQ0FBYkMsUTs7NEJBR0pDLFUsV0FEWkgsT0FBTyxDQUFDLFlBQUQsQyxVQWFIRSxRQUFRLENBQUM7QUFBQ0UsUUFBQUEsSUFBSSxFQUFFQztBQUFQLE9BQUQsQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Z0JBWERDLFMsR0FBcUIsSztnQkFDckJDLFEsR0FBbUIsQztnQkFDbkJDLFksR0FBdUIsQztnQkFDdkJDLFEsR0FBbUIsRztnQkFDbkJDLGEsR0FBd0IsQztnQkFDeEJDLE8sR0FBZ0JDLEVBQUUsQ0FBQ0MsRUFBSCxDQUFNLENBQU4sRUFBUSxDQUFSLEVBQVUsQ0FBVixDO2dCQUNoQkMsUSxHQUFpQkYsRUFBRSxDQUFDQyxFQUFILENBQU0sQ0FBTixFQUFRLENBQVIsRUFBVSxDQUFWLEM7Z0JBQ2pCRSxTLEdBQWtCSCxFQUFFLENBQUNDLEVBQUgsQ0FBTSxDQUFOLEVBQVEsQ0FBUixFQUFVLENBQVYsQztnQkFDbEJHLFEsR0FBb0IsSztnQkFDcEJDLGEsR0FBd0IsQzs7Ozs7OztrQ0FNdkIsQ0FDUjs7O2tDQUNlO0FBQ1osaUJBQUtBLGFBQUwsR0FBcUIsQ0FBckI7QUFDSDs7O3lDQUNzQkMsTSxFQUFpQjtBQUNwQyxnQkFBSUEsTUFBSixFQUFZO0FBQ1JDLGNBQUFBLFdBQVcsQ0FBQ0MsRUFBWixDQUFlQyxXQUFXLENBQUNDLFNBQVosQ0FBc0JDLFFBQXJDLEVBQThDLEtBQUtDLFNBQW5ELEVBQTZELElBQTdEO0FBQ0gsYUFGRCxNQUVPO0FBQ0hMLGNBQUFBLFdBQVcsQ0FBQ00sR0FBWixDQUFnQkosV0FBVyxDQUFDQyxTQUFaLENBQXNCQyxRQUF0QyxFQUErQyxLQUFLQyxTQUFwRCxFQUE4RCxJQUE5RDtBQUNIO0FBQ0o7OztvQ0FDaUJFLEssRUFBbUI7QUFDakMsZ0JBQUlBLEtBQUssQ0FBQ0MsU0FBTixPQUFzQixDQUExQixFQUE2QjtBQUN6QixtQkFBS0MsVUFBTCxDQUFnQixDQUFoQjtBQUNILGFBRkQsTUFFTyxJQUFJRixLQUFLLENBQUNDLFNBQU4sT0FBc0IsQ0FBMUIsRUFBNkI7QUFDaEMsbUJBQUtDLFVBQUwsQ0FBZ0IsQ0FBaEI7QUFDSDtBQUNKOzs7cUNBQ2tCQyxJLEVBQWM7QUFDN0IsZ0JBQUksS0FBS2IsUUFBVCxFQUFtQjtBQUNmO0FBQ0g7O0FBQ0QsaUJBQUtWLFNBQUwsR0FBaUIsSUFBakI7QUFDQSxpQkFBS0MsUUFBTCxHQUFnQnNCLElBQWhCO0FBQ0EsaUJBQUtyQixZQUFMLEdBQW9CLENBQXBCO0FBQ0EsaUJBQUtFLGFBQUwsR0FBcUIsS0FBS0gsUUFBTCxHQUFnQixLQUFLRSxRQUExQztBQUNBLGlCQUFLcUIsSUFBTCxDQUFVQyxXQUFWLENBQXNCLEtBQUtwQixPQUEzQjtBQUNBcUIsWUFBQUEsSUFBSSxDQUFDQyxJQUFMLENBQVVDLEdBQVYsQ0FBYyxLQUFLbkIsU0FBbkIsRUFBK0IsS0FBS0osT0FBcEMsRUFBNkNDLEVBQUUsQ0FBQ0MsRUFBSCxDQUFNLEtBQUtOLFFBQVgsRUFBb0IsQ0FBcEIsRUFBc0IsQ0FBdEIsQ0FBN0M7QUFFQSxpQkFBS1MsUUFBTCxHQUFnQixJQUFoQjs7QUFDQSxnQkFBSSxLQUFLbUIsUUFBVCxFQUFtQjtBQUNmLGtCQUFJTixJQUFJLEtBQUssQ0FBYixFQUFnQjtBQUNaLHFCQUFLTSxRQUFMLENBQWNDLElBQWQsQ0FBbUIsU0FBbkI7QUFDSCxlQUZELE1BRU8sSUFBSVAsSUFBSSxLQUFLLENBQWIsRUFBZ0I7QUFDbkIscUJBQUtNLFFBQUwsQ0FBY0MsSUFBZCxDQUFtQixTQUFuQjtBQUNIO0FBQ0o7O0FBQ0QsaUJBQUtuQixhQUFMLElBQXNCWSxJQUF0QjtBQUNIOzs7MENBQ3VCO0FBQ3BCLGlCQUFLYixRQUFMLEdBQWdCLEtBQWhCO0FBQ0EsaUJBQUtjLElBQUwsQ0FBVU8sSUFBVixDQUFlLFNBQWYsRUFBeUIsS0FBS3BCLGFBQTlCO0FBQ0g7OztpQ0FDT3FCLFMsRUFBbUI7QUFDdkIsZ0JBQUksS0FBS2hDLFNBQVQsRUFBb0I7QUFDaEIsbUJBQUtFLFlBQUwsSUFBcUI4QixTQUFyQjs7QUFDQSxrQkFBSSxLQUFLOUIsWUFBTCxHQUFvQixLQUFLQyxRQUE3QixFQUF1QztBQUNuQztBQUNBLHFCQUFLcUIsSUFBTCxDQUFVUyxXQUFWLENBQXNCLEtBQUt4QixTQUEzQjtBQUNBLHFCQUFLVCxTQUFMLEdBQWlCLEtBQWpCO0FBQ0EscUJBQUtrQyxhQUFMO0FBQ0gsZUFMRCxNQUtPO0FBQ0g7QUFDQSxxQkFBS1YsSUFBTCxDQUFVQyxXQUFWLENBQXNCLEtBQUtwQixPQUEzQjtBQUNBLHFCQUFLRyxRQUFMLENBQWMyQixDQUFkLEdBQWtCLEtBQUsvQixhQUFMLEdBQXFCNEIsU0FBdkM7QUFDQU4sZ0JBQUFBLElBQUksQ0FBQ0MsSUFBTCxDQUFVQyxHQUFWLENBQWMsS0FBS3ZCLE9BQW5CLEVBQTJCLEtBQUtBLE9BQWhDLEVBQXdDLEtBQUtHLFFBQTdDO0FBQ0EscUJBQUtnQixJQUFMLENBQVVTLFdBQVYsQ0FBc0IsS0FBSzVCLE9BQTNCO0FBQ0g7QUFDSjtBQUNKOzs7UUE1RTJCK0IsUzs7Ozs7aUJBYVUsSTs7OztvQkFmeEIiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBfZGVjb3JhdG9yLCBDb21wb25lbnQsIG1hdGgsIFZlYzMsIHN5c3RlbUV2ZW50LCBTeXN0ZW1FdmVudCwgRXZlbnRNb3VzZSwgQW5pbWF0aW9uQ2xpcCwgQW5pbWF0aW9uQ29tcG9uZW50IH0gZnJvbSBcImNjXCI7XG5jb25zdCB7IGNjY2xhc3MsIHByb3BlcnR5IH0gPSBfZGVjb3JhdG9yO1xuXG5AY2NjbGFzcyhcIlBsYXllckN0cmxcIilcbmV4cG9ydCBjbGFzcyBQbGF5ZXJDdHJsIGV4dGVuZHMgQ29tcG9uZW50IHtcbiAgICBwcml2YXRlIHN0YXJ0SnVtcDogYm9vbGVhbiA9IGZhbHNlO1xuICAgIHByaXZhdGUganVtcFN0ZXA6IG51bWJlciA9IDA7XG4gICAgcHJpdmF0ZSBjdXJySnVtcFRpbWU6IG51bWJlciA9IDA7XG4gICAgcHJpdmF0ZSBqdW1wVGltZTogbnVtYmVyID0gMC4xO1xuICAgIHByaXZhdGUgY3Vyckp1bXBTcGVlZDogbnVtYmVyID0gMDtcbiAgICBwcml2YXRlIGN1cnJQb3M6IFZlYzMgPSBjYy52MygwLDAsMCk7XG4gICAgcHJpdmF0ZSBkZWx0YVBvczogVmVjMyA9IGNjLnYzKDAsMCwwKTtcbiAgICBwcml2YXRlIHRhcmdldFBvczogVmVjMyA9IGNjLnYzKDAsMCwwKTtcbiAgICBwcml2YXRlIGlzTW92aW5nOiBib29sZWFuID0gZmFsc2U7XG4gICAgcHJpdmF0ZSBjdXJyTW92ZUluZGV4OiBudW1iZXIgPSAwO1xuXG4gICAgQHByb3BlcnR5KHt0eXBlOiBBbmltYXRpb25Db21wb25lbnR9KVxuICAgIHB1YmxpYyBCb2R5QW5pbTogQW5pbWF0aW9uQ29tcG9uZW50ID0gbnVsbDtcblxuXG4gICAgc3RhcnQgKCkge1xuICAgIH1cbiAgICBwdWJsaWMgcmVzZXQgKCkge1xuICAgICAgICB0aGlzLmN1cnJNb3ZlSW5kZXggPSAwO1xuICAgIH1cbiAgICBwdWJsaWMgc2V0SW5wdXRBY3RpdmUgKGFjdGl2ZTogYm9vbGVhbikge1xuICAgICAgICBpZiAoYWN0aXZlKSB7XG4gICAgICAgICAgICBzeXN0ZW1FdmVudC5vbihTeXN0ZW1FdmVudC5FdmVudFR5cGUuTU9VU0VfVVAsdGhpcy5vbk1vdXNlVXAsdGhpcyk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBzeXN0ZW1FdmVudC5vZmYoU3lzdGVtRXZlbnQuRXZlbnRUeXBlLk1PVVNFX1VQLHRoaXMub25Nb3VzZVVwLHRoaXMpO1xuICAgICAgICB9XG4gICAgfVxuICAgIHB1YmxpYyBvbk1vdXNlVXAgKGV2ZW50OiBFdmVudE1vdXNlKSB7XG4gICAgICAgIGlmIChldmVudC5nZXRCdXR0b24oKSA9PT0gMCkge1xuICAgICAgICAgICAgdGhpcy5qdW1wQnlTdGVwKDEpO1xuICAgICAgICB9IGVsc2UgaWYgKGV2ZW50LmdldEJ1dHRvbigpID09PSAyKSB7XG4gICAgICAgICAgICB0aGlzLmp1bXBCeVN0ZXAoMik7XG4gICAgICAgIH1cbiAgICB9XG4gICAgcHVibGljIGp1bXBCeVN0ZXAgKHN0ZXA6IG51bWJlcikge1xuICAgICAgICBpZiAodGhpcy5pc01vdmluZykge1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMuc3RhcnRKdW1wID0gdHJ1ZTtcbiAgICAgICAgdGhpcy5qdW1wU3RlcCA9IHN0ZXA7XG4gICAgICAgIHRoaXMuY3Vyckp1bXBUaW1lID0gMDtcbiAgICAgICAgdGhpcy5jdXJySnVtcFNwZWVkID0gdGhpcy5qdW1wU3RlcCAvIHRoaXMuanVtcFRpbWU7XG4gICAgICAgIHRoaXMubm9kZS5nZXRQb3NpdGlvbih0aGlzLmN1cnJQb3MpO1xuICAgICAgICBtYXRoLlZlYzMuYWRkKHRoaXMudGFyZ2V0UG9zICwgdGhpcy5jdXJyUG9zLCBjYy52Myh0aGlzLmp1bXBTdGVwLDAsMCkpXG4gICAgICAgIFxuICAgICAgICB0aGlzLmlzTW92aW5nID0gdHJ1ZTtcbiAgICAgICAgaWYgKHRoaXMuQm9keUFuaW0pIHtcbiAgICAgICAgICAgIGlmIChzdGVwID09PSAxKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5Cb2R5QW5pbS5wbGF5KCdPbmVTdGVwJyk7XG4gICAgICAgICAgICB9IGVsc2UgaWYgKHN0ZXAgPT09IDIpIHtcbiAgICAgICAgICAgICAgICB0aGlzLkJvZHlBbmltLnBsYXkoJ1R3b1N0ZXAnKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICB0aGlzLmN1cnJNb3ZlSW5kZXggKz0gc3RlcDtcbiAgICB9XG4gICAgcHVibGljIG9uT25jZUp1bXBFbmQgKCkge1xuICAgICAgICB0aGlzLmlzTW92aW5nID0gZmFsc2U7XG4gICAgICAgIHRoaXMubm9kZS5lbWl0KCdKdW1wRW5kJyx0aGlzLmN1cnJNb3ZlSW5kZXgpO1xuICAgIH1cbiAgICB1cGRhdGUgKGRlbHRhVGltZTogbnVtYmVyKSB7XG4gICAgICAgIGlmICh0aGlzLnN0YXJ0SnVtcCkge1xuICAgICAgICAgICAgdGhpcy5jdXJySnVtcFRpbWUgKz0gZGVsdGFUaW1lO1xuICAgICAgICAgICAgaWYgKHRoaXMuY3Vyckp1bXBUaW1lID4gdGhpcy5qdW1wVGltZSkge1xuICAgICAgICAgICAgICAgIC8vIGVuZFxuICAgICAgICAgICAgICAgIHRoaXMubm9kZS5zZXRQb3NpdGlvbih0aGlzLnRhcmdldFBvcyk7XG4gICAgICAgICAgICAgICAgdGhpcy5zdGFydEp1bXAgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICB0aGlzLm9uT25jZUp1bXBFbmQoKTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgLy8gdHdlZW5cbiAgICAgICAgICAgICAgICB0aGlzLm5vZGUuZ2V0UG9zaXRpb24odGhpcy5jdXJyUG9zKTtcbiAgICAgICAgICAgICAgICB0aGlzLmRlbHRhUG9zLnggPSB0aGlzLmN1cnJKdW1wU3BlZWQgKiBkZWx0YVRpbWU7XG4gICAgICAgICAgICAgICAgbWF0aC5WZWMzLmFkZCh0aGlzLmN1cnJQb3MsdGhpcy5jdXJyUG9zLHRoaXMuZGVsdGFQb3MpO1xuICAgICAgICAgICAgICAgIHRoaXMubm9kZS5zZXRQb3NpdGlvbih0aGlzLmN1cnJQb3MpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxufVxuIl19