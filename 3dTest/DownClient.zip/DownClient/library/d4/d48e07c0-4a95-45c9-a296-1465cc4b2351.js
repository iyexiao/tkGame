"use strict";

System.register("project:///assets/Scripts/GameMgr.ts", ["./PlayerCtrl"], function (_export, _context) {
  "use strict";

  var PlayerCtrl, _dec, _dec2, _dec3, _dec4, _dec5, _dec6, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4, _descriptor5, _temp, _cc, _decorator, Component, Node, Prefab, CCInteger, instantiate, LabelComponent, ccclass, property, BlockType, GameState, GameMgr;

  _export({
    _dec: void 0,
    _dec2: void 0,
    _dec3: void 0,
    _dec4: void 0,
    _dec5: void 0,
    _dec6: void 0,
    _class: void 0,
    _class2: void 0,
    _descriptor: void 0,
    _descriptor2: void 0,
    _descriptor3: void 0,
    _descriptor4: void 0,
    _descriptor5: void 0,
    _temp: void 0,
    BlockType: void 0,
    GameState: void 0
  });

  return {
    setters: [function (_PlayerCtrl) {
      PlayerCtrl = _PlayerCtrl.PlayerCtrl;
    }],
    execute: function () {
      cc._RF.push(window.module || {}, "d48e0fASpVFyaKWFGXMSyNR", "GameMgr"); // begin GameMgr


      _cc = cc;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      Node = _cc.Node;
      Prefab = _cc.Prefab;
      CCInteger = _cc.CCInteger;
      instantiate = _cc.instantiate;
      LabelComponent = _cc.LabelComponent;
      ccclass = _decorator.ccclass;
      property = _decorator.property;

      (function (BlockType) {
        BlockType[BlockType["BT_NONE"] = 0] = "BT_NONE";
        BlockType[BlockType["BT_STONE"] = 1] = "BT_STONE";
      })(BlockType || (BlockType = {}));

      (function (GameState) {
        GameState[GameState["GS_INIT"] = 0] = "GS_INIT";
        GameState[GameState["GS_PLAYING"] = 1] = "GS_PLAYING";
        GameState[GameState["GS_END"] = 2] = "GS_END";
      })(GameState || (GameState = {}));

      _export("GameMgr", GameMgr = (_dec = ccclass("GameMgr"), _dec2 = property({
        type: Prefab
      }), _dec3 = property({
        type: CCInteger
      }), _dec4 = property({
        type: PlayerCtrl
      }), _dec5 = property({
        type: Node
      }), _dec6 = property({
        type: LabelComponent
      }), _dec(_class = (_class2 = (_temp =
      /*#__PURE__*/
      function (_Component) {
        babelHelpers.inherits(GameMgr, _Component);

        function GameMgr() {
          var _babelHelpers$getProt;

          var _this;

          babelHelpers.classCallCheck(this, GameMgr);

          for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
          }

          _this = babelHelpers.possibleConstructorReturn(this, (_babelHelpers$getProt = babelHelpers.getPrototypeOf(GameMgr)).call.apply(_babelHelpers$getProt, [this].concat(args)));
          babelHelpers.initializerDefineProperty(_this, "cuberPrfb", _descriptor, babelHelpers.assertThisInitialized(_this));
          babelHelpers.initializerDefineProperty(_this, "roadLength", _descriptor2, babelHelpers.assertThisInitialized(_this));
          babelHelpers.initializerDefineProperty(_this, "playerCtrl", _descriptor3, babelHelpers.assertThisInitialized(_this));
          babelHelpers.initializerDefineProperty(_this, "startMenu", _descriptor4, babelHelpers.assertThisInitialized(_this));
          babelHelpers.initializerDefineProperty(_this, "stepLabel", _descriptor5, babelHelpers.assertThisInitialized(_this));
          _this.road = [];
          _this.currState = GameState.GS_INIT;
          return _this;
        }

        babelHelpers.createClass(GameMgr, [{
          key: "start",
          value: function start() {
            this.setCurrState(GameState.GS_INIT);
            this.playerCtrl.node.on('JumpEnd', this.onPlayerJumpEnd, this);
          }
        }, {
          key: "init",
          value: function init() {
            this.startMenu.active = true;
            this.generateRoad();
            this.playerCtrl.setInputActive(false);
            this.playerCtrl.node.setPosition(cc.v3());
            this.playerCtrl.reset();
          }
        }, {
          key: "setCurrState",
          value: function setCurrState(v) {
            var _this2 = this;

            switch (v) {
              case GameState.GS_INIT:
                this.init();
                break;

              case GameState.GS_PLAYING:
                this.startMenu.active = false;
                this.stepLabel.string = '0';
                setTimeout(function () {
                  _this2.playerCtrl.setInputActive(true);
                }, 0.1);
                break;

              case GameState.GS_END:
                break;
            }

            this.currState = v;
          }
        }, {
          key: "onStartButtonClicked",
          value: function onStartButtonClicked() {
            this.setCurrState(GameState.GS_PLAYING);
          }
        }, {
          key: "checkResult",
          value: function checkResult(moveIndex) {
            if (moveIndex <= this.roadLength) {
              if (this.road[moveIndex] == BlockType.BT_NONE) {
                this.setCurrState(GameState.GS_INIT);
              }
            } else {
              this.setCurrState(GameState.GS_INIT);
            }
          }
        }, {
          key: "onPlayerJumpEnd",
          value: function onPlayerJumpEnd(moveIndex) {
            this.stepLabel.string = '' + moveIndex;
            this.checkResult(moveIndex);
          }
        }, {
          key: "generateRoad",
          value: function generateRoad() {
            this.node.removeAllChildren();
            this.road = [];
            this.road.push(BlockType.BT_STONE);

            for (var i = 1; i < this.roadLength; i++) {
              if (this.road[i - 1] === BlockType.BT_NONE) {
                this.road.push(BlockType.BT_STONE);
              } else {
                this.road.push(Math.floor(Math.random() * 2));
              }
            }

            for (var j = 0; j < this.roadLength; j++) {
              var block = this.spawnBlockByType(this.road[j]);

              if (block) {
                this.node.addChild(block);
                block.setPosition(j, -1.5, 0);
              }
            }
          }
        }, {
          key: "spawnBlockByType",
          value: function spawnBlockByType(type) {
            var block = null;

            switch (type) {
              case BlockType.BT_STONE:
                block = instantiate(this.cuberPrfb);
                break;

              default:
                break;
            }

            return block;
          } // update (deltaTime: number) {
          //     // Your update function goes here.
          // }

        }]);
        return GameMgr;
      }(Component), _temp), (_descriptor = babelHelpers.applyDecoratedDescriptor(_class2.prototype, "cuberPrfb", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor2 = babelHelpers.applyDecoratedDescriptor(_class2.prototype, "roadLength", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return 50;
        }
      }), _descriptor3 = babelHelpers.applyDecoratedDescriptor(_class2.prototype, "playerCtrl", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor4 = babelHelpers.applyDecoratedDescriptor(_class2.prototype, "startMenu", [_dec5], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor5 = babelHelpers.applyDecoratedDescriptor(_class2.prototype, "stepLabel", [_dec6], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      })), _class2)) || _class));

      cc._RF.pop(); // end GameMgr

    }
  };
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInByb2plY3Q6Ly8vYXNzZXRzL1NjcmlwdHMvR2FtZU1nci50cyJdLCJuYW1lcyI6WyJQbGF5ZXJDdHJsIiwiY2NjbGFzcyIsIl9kZWNvcmF0b3IiLCJwcm9wZXJ0eSIsIkJsb2NrVHlwZSIsIkdhbWVTdGF0ZSIsIkdhbWVNZ3IiLCJ0eXBlIiwiUHJlZmFiIiwiQ0NJbnRlZ2VyIiwiTm9kZSIsIkxhYmVsQ29tcG9uZW50Iiwicm9hZCIsImN1cnJTdGF0ZSIsIkdTX0lOSVQiLCJzZXRDdXJyU3RhdGUiLCJwbGF5ZXJDdHJsIiwibm9kZSIsIm9uIiwib25QbGF5ZXJKdW1wRW5kIiwic3RhcnRNZW51IiwiYWN0aXZlIiwiZ2VuZXJhdGVSb2FkIiwic2V0SW5wdXRBY3RpdmUiLCJzZXRQb3NpdGlvbiIsImNjIiwidjMiLCJyZXNldCIsInYiLCJpbml0IiwiR1NfUExBWUlORyIsInN0ZXBMYWJlbCIsInN0cmluZyIsInNldFRpbWVvdXQiLCJHU19FTkQiLCJtb3ZlSW5kZXgiLCJyb2FkTGVuZ3RoIiwiQlRfTk9ORSIsImNoZWNrUmVzdWx0IiwicmVtb3ZlQWxsQ2hpbGRyZW4iLCJwdXNoIiwiQlRfU1RPTkUiLCJpIiwiTWF0aCIsImZsb29yIiwicmFuZG9tIiwiaiIsImJsb2NrIiwic3Bhd25CbG9ja0J5VHlwZSIsImFkZENoaWxkIiwiaW5zdGFudGlhdGUiLCJjdWJlclByZmIiLCJDb21wb25lbnQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFDU0EsTUFBQUEsVSxlQUFBQSxVOzs7OEVBQ2dFOzs7Ozs7Ozs7OztBQUFqRUMsTUFBQUEsTyxHQUFzQkMsVSxDQUF0QkQsTztBQUFTRSxNQUFBQSxRLEdBQWFELFUsQ0FBYkMsUTs7aUJBRVpDLFM7QUFBQUEsUUFBQUEsUyxDQUFBQSxTO0FBQUFBLFFBQUFBLFMsQ0FBQUEsUztTQUFBQSxTLEtBQUFBLFM7O2lCQUlBQyxTO0FBQUFBLFFBQUFBLFMsQ0FBQUEsUztBQUFBQSxRQUFBQSxTLENBQUFBLFM7QUFBQUEsUUFBQUEsUyxDQUFBQSxTO1NBQUFBLFMsS0FBQUEsUzs7eUJBT1FDLE8sV0FEWkwsT0FBTyxDQUFDLFNBQUQsQyxVQUdIRSxRQUFRLENBQUM7QUFBQ0ksUUFBQUEsSUFBSSxFQUFFQztBQUFQLE9BQUQsQyxVQUVSTCxRQUFRLENBQUM7QUFBQ0ksUUFBQUEsSUFBSSxFQUFFRTtBQUFQLE9BQUQsQyxVQUVSTixRQUFRLENBQUM7QUFBQ0ksUUFBQUEsSUFBSSxFQUFFUDtBQUFQLE9BQUQsQyxVQUVSRyxRQUFRLENBQUM7QUFBQ0ksUUFBQUEsSUFBSSxFQUFFRztBQUFQLE9BQUQsQyxVQUVSUCxRQUFRLENBQUM7QUFBQ0ksUUFBQUEsSUFBSSxFQUFFSTtBQUFQLE9BQUQsQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztnQkFHREMsSSxHQUFpQixFO2dCQUNqQkMsUyxHQUF1QlIsU0FBUyxDQUFDUyxPOzs7Ozs7a0NBRWhDO0FBQ0wsaUJBQUtDLFlBQUwsQ0FBa0JWLFNBQVMsQ0FBQ1MsT0FBNUI7QUFDQSxpQkFBS0UsVUFBTCxDQUFnQkMsSUFBaEIsQ0FBcUJDLEVBQXJCLENBQXdCLFNBQXhCLEVBQWtDLEtBQUtDLGVBQXZDLEVBQXVELElBQXZEO0FBQ0g7OztpQ0FDTztBQUNKLGlCQUFLQyxTQUFMLENBQWVDLE1BQWYsR0FBd0IsSUFBeEI7QUFDQSxpQkFBS0MsWUFBTDtBQUNBLGlCQUFLTixVQUFMLENBQWdCTyxjQUFoQixDQUErQixLQUEvQjtBQUNBLGlCQUFLUCxVQUFMLENBQWdCQyxJQUFoQixDQUFxQk8sV0FBckIsQ0FBaUNDLEVBQUUsQ0FBQ0MsRUFBSCxFQUFqQztBQUNBLGlCQUFLVixVQUFMLENBQWdCVyxLQUFoQjtBQUNIOzs7dUNBRW1CQyxDLEVBQWU7QUFBQTs7QUFDL0Isb0JBQVFBLENBQVI7QUFDSSxtQkFBS3ZCLFNBQVMsQ0FBQ1MsT0FBZjtBQUNJLHFCQUFLZSxJQUFMO0FBQ0E7O0FBQ0osbUJBQUt4QixTQUFTLENBQUN5QixVQUFmO0FBQ0kscUJBQUtWLFNBQUwsQ0FBZUMsTUFBZixHQUF3QixLQUF4QjtBQUNBLHFCQUFLVSxTQUFMLENBQWVDLE1BQWYsR0FBd0IsR0FBeEI7QUFDQUMsZ0JBQUFBLFVBQVUsQ0FBQyxZQUFJO0FBQ1gsa0JBQUEsTUFBSSxDQUFDakIsVUFBTCxDQUFnQk8sY0FBaEIsQ0FBK0IsSUFBL0I7QUFDSCxpQkFGUyxFQUVSLEdBRlEsQ0FBVjtBQUdBOztBQUNKLG1CQUFLbEIsU0FBUyxDQUFDNkIsTUFBZjtBQUNJO0FBWlI7O0FBY0EsaUJBQUtyQixTQUFMLEdBQWlCZSxDQUFqQjtBQUNIOzs7aURBQzhCO0FBQzNCLGlCQUFLYixZQUFMLENBQWtCVixTQUFTLENBQUN5QixVQUE1QjtBQUNIOzs7c0NBQ21CSyxTLEVBQW1CO0FBQ25DLGdCQUFJQSxTQUFTLElBQUksS0FBS0MsVUFBdEIsRUFBa0M7QUFDOUIsa0JBQUksS0FBS3hCLElBQUwsQ0FBVXVCLFNBQVYsS0FBd0IvQixTQUFTLENBQUNpQyxPQUF0QyxFQUFnRDtBQUM1QyxxQkFBS3RCLFlBQUwsQ0FBa0JWLFNBQVMsQ0FBQ1MsT0FBNUI7QUFDSDtBQUNKLGFBSkQsTUFJTztBQUNILG1CQUFLQyxZQUFMLENBQWtCVixTQUFTLENBQUNTLE9BQTVCO0FBQ0g7QUFDSjs7OzBDQUN1QnFCLFMsRUFBbUI7QUFDdkMsaUJBQUtKLFNBQUwsQ0FBZUMsTUFBZixHQUF3QixLQUFLRyxTQUE3QjtBQUNBLGlCQUFLRyxXQUFMLENBQWlCSCxTQUFqQjtBQUNIOzs7eUNBRXNCO0FBQ25CLGlCQUFLbEIsSUFBTCxDQUFVc0IsaUJBQVY7QUFDQSxpQkFBSzNCLElBQUwsR0FBWSxFQUFaO0FBQ0EsaUJBQUtBLElBQUwsQ0FBVTRCLElBQVYsQ0FBZXBDLFNBQVMsQ0FBQ3FDLFFBQXpCOztBQUVBLGlCQUFLLElBQUlDLENBQUMsR0FBRyxDQUFiLEVBQWdCQSxDQUFDLEdBQUcsS0FBS04sVUFBekIsRUFBcUNNLENBQUMsRUFBdEMsRUFBMEM7QUFDdkMsa0JBQUksS0FBSzlCLElBQUwsQ0FBVThCLENBQUMsR0FBRSxDQUFiLE1BQW9CdEMsU0FBUyxDQUFDaUMsT0FBbEMsRUFBMkM7QUFDdkMscUJBQUt6QixJQUFMLENBQVU0QixJQUFWLENBQWVwQyxTQUFTLENBQUNxQyxRQUF6QjtBQUNILGVBRkQsTUFFTztBQUNILHFCQUFLN0IsSUFBTCxDQUFVNEIsSUFBVixDQUFlRyxJQUFJLENBQUNDLEtBQUwsQ0FBV0QsSUFBSSxDQUFDRSxNQUFMLEtBQWdCLENBQTNCLENBQWY7QUFDSDtBQUNIOztBQUNELGlCQUFLLElBQUlDLENBQUMsR0FBRyxDQUFiLEVBQWdCQSxDQUFDLEdBQUcsS0FBS1YsVUFBekIsRUFBcUNVLENBQUMsRUFBdEMsRUFBMEM7QUFDdEMsa0JBQUlDLEtBQVcsR0FBRyxLQUFLQyxnQkFBTCxDQUFzQixLQUFLcEMsSUFBTCxDQUFVa0MsQ0FBVixDQUF0QixDQUFsQjs7QUFDQSxrQkFBSUMsS0FBSixFQUFXO0FBQ1AscUJBQUs5QixJQUFMLENBQVVnQyxRQUFWLENBQW1CRixLQUFuQjtBQUNBQSxnQkFBQUEsS0FBSyxDQUFDdkIsV0FBTixDQUFrQnNCLENBQWxCLEVBQW9CLENBQUMsR0FBckIsRUFBeUIsQ0FBekI7QUFDSDtBQUNKO0FBQ0o7OzsyQ0FDd0J2QyxJLEVBQXVCO0FBQzVDLGdCQUFJd0MsS0FBVyxHQUFHLElBQWxCOztBQUNBLG9CQUFReEMsSUFBUjtBQUNJLG1CQUFLSCxTQUFTLENBQUNxQyxRQUFmO0FBQ0lNLGdCQUFBQSxLQUFLLEdBQUdHLFdBQVcsQ0FBQyxLQUFLQyxTQUFOLENBQW5CO0FBQ0E7O0FBRUo7QUFDSTtBQU5SOztBQVFBLG1CQUFPSixLQUFQO0FBQ0gsVyxDQUVEO0FBQ0E7QUFDQTs7OztRQWpHeUJLLFM7Ozs7O2lCQUdFLEk7Ozs7Ozs7aUJBRUMsRTs7Ozs7OztpQkFFSSxJOzs7Ozs7O2lCQUVQLEk7Ozs7Ozs7aUJBRVUsSTs7OztvQkF4QnJCIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgX2RlY29yYXRvciwgQ29tcG9uZW50LCBOb2RlLCBQcmVmYWIsIENDSW50ZWdlciwgaW5zdGFudGlhdGUsIExhYmVsQ29tcG9uZW50IH0gZnJvbSBcImNjXCI7XG5pbXBvcnQgeyBQbGF5ZXJDdHJsIH0gZnJvbSBcIi4vUGxheWVyQ3RybFwiO1xuY29uc3QgeyBjY2NsYXNzLCBwcm9wZXJ0eSB9ID0gX2RlY29yYXRvcjtcblxuZW51bSBCbG9ja1R5cGUge1xuICAgIEJUX05PTkUsXG4gICAgQlRfU1RPTkUsXG59XG5lbnVtIEdhbWVTdGF0ZSB7XG4gICAgR1NfSU5JVCxcbiAgICBHU19QTEFZSU5HLFxuICAgIEdTX0VORCxcbn1cblxuQGNjY2xhc3MoXCJHYW1lTWdyXCIpXG5leHBvcnQgY2xhc3MgR2FtZU1nciBleHRlbmRzIENvbXBvbmVudCB7XG5cbiAgICBAcHJvcGVydHkoe3R5cGU6IFByZWZhYn0pXG4gICAgcHVibGljIGN1YmVyUHJmYjogUHJlZmFiID0gbnVsbDtcbiAgICBAcHJvcGVydHkoe3R5cGU6IENDSW50ZWdlcn0pXG4gICAgcHVibGljIHJvYWRMZW5ndGg6IE51bWJlciA9IDUwO1xuICAgIEBwcm9wZXJ0eSh7dHlwZTogUGxheWVyQ3RybH0pXG4gICAgcHVibGljIHBsYXllckN0cmw6IFBsYXllckN0cmwgPSBudWxsO1xuICAgIEBwcm9wZXJ0eSh7dHlwZTogTm9kZX0pXG4gICAgcHVibGljIHN0YXJ0TWVudTogTm9kZSA9IG51bGw7XG4gICAgQHByb3BlcnR5KHt0eXBlOiBMYWJlbENvbXBvbmVudH0pXG4gICAgcHVibGljIHN0ZXBMYWJlbDogTGFiZWxDb21wb25lbnQgPSBudWxsO1xuXG4gICAgcHJpdmF0ZSByb2FkOiBudW1iZXJbXSA9IFtdO1xuICAgIHByaXZhdGUgY3VyclN0YXRlOiBHYW1lU3RhdGUgPSBHYW1lU3RhdGUuR1NfSU5JVDtcblxuICAgIHN0YXJ0ICgpIHtcbiAgICAgICAgdGhpcy5zZXRDdXJyU3RhdGUoR2FtZVN0YXRlLkdTX0lOSVQpO1xuICAgICAgICB0aGlzLnBsYXllckN0cmwubm9kZS5vbignSnVtcEVuZCcsdGhpcy5vblBsYXllckp1bXBFbmQsdGhpcyk7XG4gICAgfVxuICAgIGluaXQgKCkge1xuICAgICAgICB0aGlzLnN0YXJ0TWVudS5hY3RpdmUgPSB0cnVlO1xuICAgICAgICB0aGlzLmdlbmVyYXRlUm9hZCgpO1xuICAgICAgICB0aGlzLnBsYXllckN0cmwuc2V0SW5wdXRBY3RpdmUoZmFsc2UpO1xuICAgICAgICB0aGlzLnBsYXllckN0cmwubm9kZS5zZXRQb3NpdGlvbihjYy52MygpKTtcbiAgICAgICAgdGhpcy5wbGF5ZXJDdHJsLnJlc2V0KCk7XG4gICAgfVxuICAgIFxuICAgIHB1YmxpYyBzZXRDdXJyU3RhdGUodiA6IEdhbWVTdGF0ZSkge1xuICAgICAgICBzd2l0Y2ggKHYpIHtcbiAgICAgICAgICAgIGNhc2UgR2FtZVN0YXRlLkdTX0lOSVQ6XG4gICAgICAgICAgICAgICAgdGhpcy5pbml0KCk7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlIEdhbWVTdGF0ZS5HU19QTEFZSU5HOlxuICAgICAgICAgICAgICAgIHRoaXMuc3RhcnRNZW51LmFjdGl2ZSA9IGZhbHNlO1xuICAgICAgICAgICAgICAgIHRoaXMuc3RlcExhYmVsLnN0cmluZyA9ICcwJztcbiAgICAgICAgICAgICAgICBzZXRUaW1lb3V0KCgpPT57XG4gICAgICAgICAgICAgICAgICAgIHRoaXMucGxheWVyQ3RybC5zZXRJbnB1dEFjdGl2ZSh0cnVlKTtcbiAgICAgICAgICAgICAgICB9LDAuMSk7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlIEdhbWVTdGF0ZS5HU19FTkQ6XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5jdXJyU3RhdGUgPSB2O1xuICAgIH1cbiAgICBwdWJsaWMgb25TdGFydEJ1dHRvbkNsaWNrZWQgKCkge1xuICAgICAgICB0aGlzLnNldEN1cnJTdGF0ZShHYW1lU3RhdGUuR1NfUExBWUlORyk7XG4gICAgfVxuICAgIHB1YmxpYyBjaGVja1Jlc3VsdCAobW92ZUluZGV4OiBudW1iZXIpIHtcbiAgICAgICAgaWYgKG1vdmVJbmRleCA8PSB0aGlzLnJvYWRMZW5ndGgpIHtcbiAgICAgICAgICAgIGlmICh0aGlzLnJvYWRbbW92ZUluZGV4XSA9PSBCbG9ja1R5cGUuQlRfTk9ORSApIHtcbiAgICAgICAgICAgICAgICB0aGlzLnNldEN1cnJTdGF0ZShHYW1lU3RhdGUuR1NfSU5JVCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICB0aGlzLnNldEN1cnJTdGF0ZShHYW1lU3RhdGUuR1NfSU5JVCk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgcHVibGljIG9uUGxheWVySnVtcEVuZCAobW92ZUluZGV4OiBudW1iZXIpIHtcbiAgICAgICAgdGhpcy5zdGVwTGFiZWwuc3RyaW5nID0gJycgKyBtb3ZlSW5kZXg7XG4gICAgICAgIHRoaXMuY2hlY2tSZXN1bHQobW92ZUluZGV4KTtcbiAgICB9XG4gICAgXG4gICAgcHVibGljIGdlbmVyYXRlUm9hZCAoKSB7XG4gICAgICAgIHRoaXMubm9kZS5yZW1vdmVBbGxDaGlsZHJlbigpO1xuICAgICAgICB0aGlzLnJvYWQgPSBbXTtcbiAgICAgICAgdGhpcy5yb2FkLnB1c2goQmxvY2tUeXBlLkJUX1NUT05FKTtcblxuICAgICAgICBmb3IgKGxldCBpID0gMTsgaSA8IHRoaXMucm9hZExlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgIGlmICh0aGlzLnJvYWRbaSAtMV0gPT09IEJsb2NrVHlwZS5CVF9OT05FKSB7XG4gICAgICAgICAgICAgICB0aGlzLnJvYWQucHVzaChCbG9ja1R5cGUuQlRfU1RPTkUpO1xuICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgdGhpcy5yb2FkLnB1c2goTWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpICogMikpO1xuICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgZm9yIChsZXQgaiA9IDA7IGogPCB0aGlzLnJvYWRMZW5ndGg7IGorKykge1xuICAgICAgICAgICAgbGV0IGJsb2NrOiBOb2RlID0gdGhpcy5zcGF3bkJsb2NrQnlUeXBlKHRoaXMucm9hZFtqXSk7XG4gICAgICAgICAgICBpZiAoYmxvY2spIHtcbiAgICAgICAgICAgICAgICB0aGlzLm5vZGUuYWRkQ2hpbGQoYmxvY2spO1xuICAgICAgICAgICAgICAgIGJsb2NrLnNldFBvc2l0aW9uKGosLTEuNSwwKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cbiAgICBwdWJsaWMgc3Bhd25CbG9ja0J5VHlwZSAodHlwZTogQmxvY2tUeXBlKTogTm9kZSB7XG4gICAgICAgIGxldCBibG9jazogTm9kZSA9IG51bGw7XG4gICAgICAgIHN3aXRjaCAodHlwZSkge1xuICAgICAgICAgICAgY2FzZSBCbG9ja1R5cGUuQlRfU1RPTkU6XG4gICAgICAgICAgICAgICAgYmxvY2sgPSBpbnN0YW50aWF0ZSh0aGlzLmN1YmVyUHJmYik7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgIFxuICAgICAgICAgICAgZGVmYXVsdDpcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gYmxvY2s7XG4gICAgfVxuXG4gICAgLy8gdXBkYXRlIChkZWx0YVRpbWU6IG51bWJlcikge1xuICAgIC8vICAgICAvLyBZb3VyIHVwZGF0ZSBmdW5jdGlvbiBnb2VzIGhlcmUuXG4gICAgLy8gfVxufVxuIl19